<?php
namespace backend\models;
use yii\db\ActiveRecord;

class Reading extends ActiveRecord{

}